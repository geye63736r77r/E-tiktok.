const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');

const app = express();
const db = new sqlite3.Database('./database.sqlite');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'secret1234',
  resave: false,
  saveUninitialized: true
}));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Create tables if not exist
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    balance REAL DEFAULT 0
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    description TEXT,
    amount REAL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS withdraw_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    address TEXT,
    amount REAL,
    status TEXT DEFAULT 'pending'
  )`);

  // Insert sample orders if empty
  db.get("SELECT COUNT(*) as count FROM orders", (err, row) => {
    if (row.count === 0) {
      db.run(`INSERT INTO orders (description, amount) VALUES 
        ('Product Review - $1.00', 1),
        ('Social Media Share - $0.5', 0.5),
        ('Survey Completion - $2.00', 2)`);
    }
  });
});

// Middleware to check login
function checkAuth(req, res, next) {
  if (req.session.userId) {
    next();
  } else {
    res.redirect('/login');
  }
}

// Routes
app.get('/', checkAuth, (req, res) => {
  db.all('SELECT * FROM orders', (err, orders) => {
    db.get('SELECT balance FROM users WHERE id = ?', [req.session.userId], (err, user) => {
      res.render('index', { username: req.session.username, orders, balance: user.balance });
    });
  });
});

app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
    if (!user) {
      return res.render('login', { error: 'Invalid username or password' });
    }
    bcrypt.compare(password, user.password, (err, result) => {
      if (result) {
        req.session.userId = user.id;
        req.session.username = user.username;
        res.redirect('/');
      } else {
        res.render('login', { error: 'Invalid username or password' });
      }
    });
  });
});

app.get('/register', (req, res) => {
  res.render('register', { error: null });
});

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  bcrypt.hash(password, 10, (err, hash) => {
    db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, hash], function(err) {
      if (err) {
        return res.render('register', { error: 'Username already exists' });
      }
      res.redirect('/login');
    });
  });
});

app.post('/grab-order', checkAuth, (req, res) => {
  const orderId = req.body.orderId;
  db.get('SELECT amount FROM orders WHERE id = ?', [orderId], (err, order) => {
    if (!order) return res.status(400).send('Order not found');
    db.run('UPDATE users SET balance = balance + ? WHERE id = ?', [order.amount, req.session.userId], (err) => {
      if (err) return res.status(500).send('Database error');
      res.redirect('/');
    });
  });
});

app.get('/withdraw', checkAuth, (req, res) => {
  res.render('withdraw', { error: null, success: null });
});

app.post('/withdraw', checkAuth, (req, res) => {
  const { address, amount } = req.body;
  const amountNum = parseFloat(amount);
  if (!address || isNaN(amountNum) || amountNum <= 0) {
    return res.render('withdraw', { error: 'Invalid address or amount', success: null });
  }
  db.get('SELECT balance FROM users WHERE id = ?', [req.session.userId], (err, user) => {
    if (user.balance < amountNum) {
      return res.render('withdraw', { error: 'Insufficient balance', success: null });
    }
    db.run('INSERT INTO withdraw_requests (user_id, address, amount) VALUES (?, ?, ?)', [req.session.userId, address, amountNum], (err) => {
      if (err) return res.render('withdraw', { error: 'Database error', success: null });
      // Deduct balance
      db.run('UPDATE users SET balance = balance - ? WHERE id = ?', [amountNum, req.session.userId]);
      res.render('withdraw', { error: null, success: 'Withdraw request submitted successfully' });
    });
  });
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// Admin panel route to view withdraw requests (simple, no auth)
app.get('/admin/withdraw-requests', (req, res) => {
  db.all('SELECT wr.id, wr.address, wr.amount, wr.status, u.username FROM withdraw_requests wr JOIN users u ON wr.user_id = u.id ORDER BY wr.id DESC', (err, requests) => {
    res.render('admin_requests', { requests });
  });
});

// Start server
app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});